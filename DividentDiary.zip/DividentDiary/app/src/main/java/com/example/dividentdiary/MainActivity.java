package com.example.dividentdiary;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Button;
import android.widget.TextView;
import android.widget.ArrayAdapter;
import android.view.View;
import android.content.Intent;
import android.net.Uri;

import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import com.google.android.material.navigation.NavigationView;

public class MainActivity extends AppCompatActivity {

    EditText etAmount, etRate;
    Spinner spinnerMonths;
    Button btnCalculate;
    TextView tvResult;
    DrawerLayout drawerLayout;
    NavigationView navView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Drawer and navigation
        drawerLayout = findViewById(R.id.drawerLayout);
        navView = findViewById(R.id.navView);

        // Inputs
        etAmount = findViewById(R.id.etAmount);
        etRate = findViewById(R.id.etRate);
        spinnerMonths = findViewById(R.id.spinnerMonths);
        tvResult = findViewById(R.id.tvResult);
        btnCalculate = findViewById(R.id.btnCalculate);

        // Spinner values
        String[] months = {"1","2","3","4","5","6","7","8","9","10","11","12"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, months);
        spinnerMonths.setAdapter(adapter);

        // Calculate button
        btnCalculate.setOnClickListener(v -> {
            calculateDividend();
        });

        // Click on menu icon to open drawer
        findViewById(R.id.btnMenu).setOnClickListener(v -> {
            drawerLayout.openDrawer(navView);
        });

        // Handle menu item selections
        navView.setNavigationItemSelectedListener(item -> {
            int id = item.getItemId();

            if (id == R.id.nav_home) {
                drawerLayout.closeDrawers();
            }
            else if (id == R.id.nav_about) {
                startActivity(new Intent(MainActivity.this, AboutActivity.class));
            }
            else if (id == R.id.nav_github) {
                openGithub();
            }
            else if (id == R.id.nav_exit) {
                finishAffinity();
                System.exit(0);
            }

            return true;
        });
    }

    // Open GitHub link
    private void openGithub() {
        String githubUrl = "https://github.com/srhmhd/DividentDiary";
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(githubUrl));
        startActivity(intent);
    }

    private void calculateDividend() {

        if(etAmount.getText().toString().isEmpty() ||
                etRate.getText().toString().isEmpty()) {
            tvResult.setText("Please enter all required fields.");
            return;
        }

        double amount = Double.parseDouble(etAmount.getText().toString());
        double rate = Double.parseDouble(etRate.getText().toString()) / 100;
        int months = Integer.parseInt(spinnerMonths.getSelectedItem().toString());

        double monthlyDividend = (rate / 12) * amount;
        double totalDividend = monthlyDividend * months;

        String formatted = String.format("%.2f", totalDividend);
        tvResult.setText("Dividend earned: RM " + formatted);
    }
}
